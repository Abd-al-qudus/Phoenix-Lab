import 'package:flutter/material.dart';
import 'package:mydictionary/widgets/word_search.dart';

class SearchWord extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const WordSearch();
  }
}
